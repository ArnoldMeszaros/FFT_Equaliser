# bram_ctrl
interconnect variacio, atnezni 
szerinem full sablon
OK
# bram
sablon (160 old gpio), atirni
szerinem full sablon
OK
# soft
read vaw file - OK
form data from wav - OK
send data points to bram (sima .cpp filebol kiszedni), minden a mainbol kiveve az fft + ifft
# hard
to be changed to fft + ifft + filter?
popravi void HARD::FFT()
    kako??
# interconnect
nincs benne nagy fantazia, sablon a vezbankabol (167old sys_bus)
szerinem full sablon
OK
# main
part with args #tbd 
OK
# typedefs.hpp
atirni sajatokra - def data, addr, size..
# utils
atirni sajatokra - num_t to_fixed, void to_uchar, #tbd
# vp
OK
